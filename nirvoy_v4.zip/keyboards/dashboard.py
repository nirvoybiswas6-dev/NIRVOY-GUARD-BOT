from telegram import InlineKeyboardButton, InlineKeyboardMarkup

def get_dashboard_keyboard(chat_id: int, settings: dict) -> InlineKeyboardMarkup:
    spam_stat = "🟢" if settings.get("anti_spam") else "🔴"
    promo_stat = "🟢" if settings.get("anti_promo") else "🔴"
    link_stat = "🟢" if settings.get("anti_link") else "🔴"
    raid_stat = "🟢" if settings.get("anti_raid") else "🔴"
    del_stat = "🟢" if settings.get("delete_punish") else "🔴"

    keyboard = [
        [
            InlineKeyboardButton(f"🛡️ স্প্যাম {spam_stat}", callback_data=f"toggle:anti_spam:{chat_id}"),
            InlineKeyboardButton(f"🚫 প্রমোশন {promo_stat}", callback_data=f"toggle:anti_promo:{chat_id}")
        ],
        [
            InlineKeyboardButton(f"🔗 লিংক ফিল্টার {link_stat}", callback_data=f"toggle:anti_link:{chat_id}"),
            InlineKeyboardButton(f"⚡ অ্যান্টি-রেইড {raid_stat}", callback_data=f"toggle:anti_raid:{chat_id}")
        ],
        [
            InlineKeyboardButton(f"🗑️ অটো-ডিলিট {del_stat}", callback_data=f"toggle:delete_punish:{chat_id}"),
            InlineKeyboardButton("📊 লাইভ স্ট্যাটাস", callback_data=f"menu:stats:{chat_id}")
        ],
        [
            InlineKeyboardButton("💬 নিষিদ্ধ শব্দ তালিকা", callback_data=f"menu:words:{chat_id}"),
            InlineKeyboardButton("🌐 লিংক হোয়াইটলিস্ট", callback_data=f"menu:links:{chat_id}")
        ],
        [
            InlineKeyboardButton("🤖 AI CONTROL", callback_data=f"menu:ai:{chat_id}"),
            InlineKeyboardButton("⚙️ শাস্তি কনফিগ", callback_data=f"menu:punish:{chat_id}")
        ],
        [
            InlineKeyboardButton("🔊 সতর্কবার্তা ভয়েস সেটিংস", callback_data=f"menu:voices:{chat_id}")
        ],
        [
            InlineKeyboardButton("🌐 ভাষা পরিবর্তন", callback_data=f"menu:lang:{chat_id}")
        ],
        [
            InlineKeyboardButton("🔄 রিফ্রেশ", callback_data=f"refresh:{chat_id}"),
            InlineKeyboardButton("🚪 লগআউট", callback_data="auth:logout")
        ]
    ]
    return InlineKeyboardMarkup(keyboard)

def get_back_keyboard(chat_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🔙 প্রধান মেনু", callback_data=f"back:home:{chat_id}")]
    ])