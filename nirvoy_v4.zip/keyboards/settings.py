from telegram import InlineKeyboardButton, InlineKeyboardMarkup

def get_punish_settings_keyboard(chat_id: int, current_action: str) -> InlineKeyboardMarkup:
    mute_mark = "✅" if current_action == "mute" else ""
    ban_mark = "✅" if current_action == "ban" else ""
    kick_mark = "✅" if current_action == "kick" else ""

    keyboard = [
        [InlineKeyboardButton(f"🔇 মিউট {mute_mark}", callback_data=f"setaction:mute:{chat_id}")],
        [InlineKeyboardButton(f"🚫 পার্মানেন্ট ব্যান {ban_mark}", callback_data=f"setaction:ban:{chat_id}")],
        [InlineKeyboardButton(f"👢 গ্রুপ থেকে কিক {kick_mark}", callback_data=f"setaction:kick:{chat_id}")],
        [InlineKeyboardButton("🔙 ফিরে যান", callback_data=f"back:home:{chat_id}")]
    ]
    return InlineKeyboardMarkup(keyboard)