import unittest
from services.spam_detector import SpamDetector

class TestSpamDetector(unittest.TestCase):
    def setUp(self):
        self.detector = SpamDetector()

    def test_repetition(self):
        chat_id, user_id = 1001, 2001
        self.assertFalse(self.detector.is_repeating(chat_id, user_id, "হ্যালো ভাই"))
        self.assertFalse(self.detector.is_repeating(chat_id, user_id, "হ্যালো ভাই"))
        self.assertTrue(self.detector.is_repeating(chat_id, user_id, "হ্যালো ভাই"))

    def test_emojis(self):
        text = "🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥"
        self.assertTrue(self.detector.has_excessive_emojis(text))

    def test_char_flood(self):
        text = "ভাইইইইইইইইইইইইইই"
        self.assertTrue(self.detector.has_char_repetition(text))

if __name__ == "__main__":
    unittest.main()