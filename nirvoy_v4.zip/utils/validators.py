import json
from pathlib import Path
from typing import Any, Dict
from config import BASE_DIR, DEFAULT_LANG

_locales_cache: Dict[str, Dict[str, str]] = {}

def load_locales():
    locales_dir = BASE_DIR / "locales"
    for file in locales_dir.glob("*.json"):
        with open(file, "r", encoding="utf-8") as f:
            _locales_cache[file.stem] = json.load(f)

load_locales()

def get_text(key: str, lang: str = DEFAULT_LANG, **kwargs: Any) -> str:
    lang_dict = _locales_cache.get(lang) or _locales_cache.get("bn", {})
    text = lang_dict.get(key) or _locales_cache.get("en", {}).get(key, key)
    if kwargs:
        try:
            return text.format(**kwargs)
        except KeyError:
            return text
    return text