import hmac
import hashlib
from datetime import datetime, timedelta
from typing import Dict
from config import ADMIN_SECRET_KEY, OWNER_ID, SESSION_EXPIRY_MINUTES

_sessions: Dict[int, datetime] = {}

def verify_secret_key(provided_key: str) -> bool:
    return hmac.compare_digest(
        hashlib.sha256(provided_key.encode()).hexdigest(),
        hashlib.sha256(ADMIN_SECRET_KEY.encode()).hexdigest()
    )

def create_admin_session(user_id: int):
    _sessions[user_id] = datetime.utcnow() + timedelta(minutes=SESSION_EXPIRY_MINUTES)

def is_session_valid(user_id: int) -> bool:
    if user_id == OWNER_ID:
        return True
    expiry = _sessions.get(user_id)
    if not expiry:
        return False
    if datetime.utcnow() > expiry:
        _sessions.pop(user_id, None)
        return False
    return True

def terminate_session(user_id: int):
    _sessions.pop(user_id, None)