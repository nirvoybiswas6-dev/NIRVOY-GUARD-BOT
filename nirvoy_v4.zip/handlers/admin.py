from telegram import Update
from telegram.ext import ContextTypes
from utils.security import verify_secret_key, create_admin_session, terminate_session
from database.db import db
from keyboards.dashboard import get_dashboard_keyboard
from utils.validators import get_text

async def secret_key_receiver(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if not user or not context.user_data.get("awaiting_secret"):
        return

    key = update.message.text.strip()
    if verify_secret_key(key):
        context.user_data["awaiting_secret"] = False
        create_admin_session(user.id)
        target_chat_id = context.user_data.get("current_chat_id", user.id)
        settings = await db.get_chat_settings(target_chat_id)
        await update.message.reply_text(
            get_text("login_success", settings.get("language", "bn")),
            reply_markup=get_dashboard_keyboard(target_chat_id, settings)
        )
    else:
        await update.message.reply_text(get_text("login_failed", "bn"))