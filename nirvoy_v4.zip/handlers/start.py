from telegram import Update
from telegram.ext import ContextTypes
from config import OWNER_ID
from utils.security import is_session_valid
from database.db import db
from keyboards.dashboard import get_dashboard_keyboard
from utils.validators import get_text

async def start_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    chat = update.effective_chat
    if not user:
        return

    if chat.type in ["group", "supergroup"]:
        await update.message.reply_text("🛡️ NIRVOY GUARD PRO সক্রিয় রয়েছে। অ্যাডমিন ড্যাশবোর্ডের জন্য আমাকে ইনবক্সে /start পাঠান।")
        return

    if user.id == OWNER_ID or is_session_valid(user.id):
        target_chat_id = context.user_data.get("current_chat_id", user.id)
        settings = await db.get_chat_settings(target_chat_id)
        text = get_text("welcome_dashboard", settings.get("language", "bn"), chat_title=settings.get("title", "Dashboard"))
        await update.message.reply_text(text, reply_markup=get_dashboard_keyboard(target_chat_id, settings), parse_mode="Markdown")
    else:
        context.user_data["awaiting_secret"] = True
        await update.message.reply_text(get_text("secret_key_prompt", "bn"))