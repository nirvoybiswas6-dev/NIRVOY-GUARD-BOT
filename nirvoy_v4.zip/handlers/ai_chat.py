import html
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from utils.security import is_session_valid
from database.db import db
from services.ai_assistant import ai_assistant
from services.gemini_client import gemini_client


def ai_menu_keyboard(chat_id: int):
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🤖 AI-কে প্রশ্ন করুন", callback_data=f"ai:start:{chat_id}"), InlineKeyboardButton("🩺 AI STATUS", callback_data=f"ai:status:{chat_id}")],
        [InlineKeyboardButton("📋 বর্তমান সেটিংস", callback_data=f"ai:settings:{chat_id}")],
        [InlineKeyboardButton("🔙 প্রধান মেনু", callback_data=f"back:home:{chat_id}")]
    ])


async def open_ai_menu(update: Update, context: ContextTypes.DEFAULT_TYPE, chat_id: int):
    context.user_data["current_chat_id"] = chat_id
    context.user_data["awaiting_ai"] = True
    await update.message.reply_text(
        "🤖 <b>NIRVOY AI CONTROL</b>\n\nবাংলায় লিখে আপনার প্রশ্ন করুন বা নিরাপদ moderation setting পরিবর্তনের অনুরোধ দিন।\n\nউদাহরণ: <i>এই গ্রুপে anti-promo চালু রাখো</i>",
        reply_markup=ai_menu_keyboard(chat_id), parse_mode="HTML")


async def ai_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if not user or not is_session_valid(user.id):
        if update.message:
            await update.message.reply_text("🔒 আগে admin session-এ login করুন।")
        return
    chat_id = context.user_data.get("current_chat_id", user.id)
    context.user_data["current_chat_id"] = chat_id
    context.user_data["awaiting_ai"] = True
    await update.message.reply_text(
        "🤖 <b>NIRVOY AI CONTROL</b> চালু হয়েছে।\n\nবাংলা, English বা Banglish-এ আপনার প্রশ্ন লিখুন।",
        reply_markup=ai_menu_keyboard(chat_id), parse_mode="HTML")


async def ai_status_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if not user or not is_session_valid(user.id):
        await update.message.reply_text("🔒 আগে admin session-এ login করুন।")
        return
    await send_ai_status(update.message.reply_text)


async def send_ai_status(reply_func):
    if not gemini_client.ready:
        await reply_func("❌ <b>AI OFF</b>\n\nGEMINI_API_KEY সেট করা নেই।", parse_mode="HTML")
        return
    ok, models, error = await gemini_client.list_models()
    if ok:
        active = gemini_client.active_model or "auto"
        preview = ", ".join(models[:8]) if models else "কোনো generateContent model পাওয়া যায়নি"
        await reply_func(
            f"🩺 <b>NIRVOY AI STATUS</b>\n\n🟢 API key: সেট আছে\n🤖 Active model: <code>{html.escape(active)}</code>\n📦 Available: <code>{html.escape(preview)}</code>",
            parse_mode="HTML")
    else:
        await reply_func(f"🔴 <b>NIRVOY AI STATUS</b>\n\n❌ {html.escape(error)}", parse_mode="HTML")


async def ai_text_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    message = update.effective_message
    if not user or not message or not message.text or not is_session_valid(user.id):
        return
    if not context.user_data.get("awaiting_ai"):
        return

    chat_id = int(context.user_data.get("current_chat_id", user.id))
    settings = await db.get_chat_settings(chat_id)
    blacklisted = await db.get_blacklisted_words(chat_id)
    domains = await db.get_allowed_domains(chat_id)
    result = await ai_assistant.chat_or_plan(message.text, settings, blacklisted, domains)

    if result["type"] == "answer":
        await message.reply_text(f"🤖 <b>NIRVOY AI</b>\n\n{html.escape(result['answer'])}", parse_mode="HTML", reply_markup=ai_menu_keyboard(chat_id))
        return

    action = result["action"]
    name, value = action["name"], action["value"]
    reason = action.get("reason") or "আপনার অনুরোধ অনুযায়ী পরিবর্তন প্রস্তাব করা হয়েছে।"
    if name == "show_settings":
        await message.reply_text(format_settings(settings, blacklisted, domains), parse_mode="HTML", reply_markup=ai_menu_keyboard(chat_id))
        return
    if name == "none":
        await message.reply_text("🤖 এই অনুরোধে কোনো configuration change প্রয়োজন নেই।", reply_markup=ai_menu_keyboard(chat_id))
        return

    context.user_data["pending_ai_action"] = action
    context.user_data["pending_ai_chat_id"] = chat_id
    kb = InlineKeyboardMarkup([[InlineKeyboardButton("✅ পরিবর্তন করুন", callback_data=f"ai:confirm:{chat_id}"), InlineKeyboardButton("❌ বাতিল", callback_data=f"ai:cancel:{chat_id}")]])
    await message.reply_text(
        f"🤖 <b>AI পরিবর্তনের প্রস্তাব</b>\n\n🛠️ <b>পরিবর্তন:</b> {html.escape(action_label(action))}\n📌 <b>কারণ:</b> {html.escape(reason)}\n\nপরিবর্তন করতে নিচের Confirm চাপুন।",
        reply_markup=kb, parse_mode="HTML")


def action_label(action):
    name, value = action["name"], action["value"]
    if name == "set_setting":
        return f"{value['key']} → {'ON' if value['value'] else 'OFF'}"
    if name == "add_blacklist": return f"নিষিদ্ধ শব্দ যোগ → {value}"
    if name == "remove_blacklist": return f"নিষিদ্ধ শব্দ বাদ → {value}"
    if name == "add_domain": return f"Whitelist domain যোগ → {value}"
    if name == "remove_domain": return f"Whitelist domain বাদ → {value}"
    if name == "set_warn_action": return f"Warn action → {value}"
    if name == "set_max_warns": return f"Max warns → {value}"
    return name


def format_settings(settings, words, domains):
    flags = ["anti_spam", "anti_promo", "anti_link", "anti_raid", "delete_punish"]
    lines = ["⚙️ <b>বর্তমান সেটিংস</b>"]
    for key in flags:
        lines.append(f"• {key}: {'🟢 ON' if settings.get(key) else '🔴 OFF'}")
    lines += [f"• warn_action: {html.escape(str(settings.get('warn_action')))}", f"• max_warns: {settings.get('max_warns')}", f"• blacklist: {len(words)}টি", f"• whitelist: {len(domains)}টি"]
    return "\n".join(lines)
