from telegram import Update
from telegram.ext import ContextTypes
from database.db import db
from services.spam_detector import spam_engine
from services.promotion_detector import promo_engine
from services.link_filter import link_engine
from services.raid_protection import raid_engine
from handlers.commands import is_user_admin
from utils.logger import log

async def group_moderation_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat = update.effective_chat
    user = update.effective_user
    message = update.effective_message
    if not chat or not user or not message or not message.text:
        return
    if chat.type not in ["group", "supergroup"]:
        return
    if await is_user_admin(chat, user.id):
        return

    settings = await db.get_chat_settings(chat.id)
    text = message.text

    # ১. অ্যান্টি-স্প্যাম ভ্যালিডেশন
    if settings.get("anti_spam"):
        if spam_engine.is_flooding(chat.id, user.id) or \
           spam_engine.is_repeating(chat.id, user.id, text) or \
           spam_engine.has_excessive_emojis(text) or \
           spam_engine.has_char_repetition(text):
            try:
                await message.delete()
                await db.log_action(chat.id, user.id, "DELETE", "স্প্যামিং বা ইমোজি ফ্লাডিং")
            except Exception as e:
                log.warning(f"মেসেজ ডিলিট ব্যর্থ: {e}")
            return

    # ২. অ্যান্টি-প্রমোশন ভ্যালিডেশন
    if settings.get("anti_promo"):
        blacklisted = await db.get_blacklisted_words(chat.id)
        is_promo, reason = promo_engine.is_promotional(text, blacklisted)
        if is_promo:
            try:
                await message.delete()
                await db.log_action(chat.id, user.id, "DELETE", f"বিজ্ঞাপন: {reason}")
            except Exception as e:
                log.warning(f"মেসেজ ডিলিট ব্যর্থ: {e}")
            return

    # ৩. লিংক ফিল্টারিং
    if settings.get("anti_link"):
        whitelist = await db.get_allowed_domains(chat.id)
        allowed, reason = link_engine.validate_content_links(text, whitelist)
        if not allowed:
            try:
                await message.delete()
                await db.log_action(chat.id, user.id, "DELETE", f"অননুমোদিত লিংক: {reason}")
            except Exception as e:
                log.warning(f"লিংক ডিলিট ব্যর্থ: {e}")
            return

async def member_join_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat = update.effective_chat
    if not chat or not update.message or not update.message.new_chat_members:
        return
    settings = await db.get_chat_settings(chat.id)
    if settings.get("anti_raid"):
        for member in update.message.new_chat_members:
            if member.is_bot:
                continue
            if raid_engine.record_join_and_check(chat.id):
                await update.message.reply_text("🚨 অস্বাভাবিক রেইড শনাক্ত হয়েছে! গ্রুপের সুরক্ষা নিশ্চিত করতে সাময়িক লকডাউন দেওয়া হলো।")
                await db.update_chat_setting(chat.id, "lockdown", 1)
                break