from telegram import Update
from telegram.ext import ContextTypes
from database.db import db
from utils.security import is_session_valid, terminate_session
from keyboards.dashboard import get_dashboard_keyboard, get_back_keyboard
from keyboards.settings import get_punish_settings_keyboard
from services.analytics import analytics
from utils.validators import get_text
from handlers.ai_chat import open_ai_menu, ai_menu_keyboard, format_settings
from services.ai_chat_exec import execute_ai_action
from handlers.ai_chat import send_ai_status
from handlers.voices import voice_settings_message

async def callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user = update.effective_user
    data = query.data

    if not user or not is_session_valid(user.id):
        await query.edit_message_text(get_text("session_expired", "bn"))
        return

    parts = data.split(":")
    action = parts[0]

    if action == "toggle":
        setting_key = parts[1]
        chat_id = int(parts[2])
        current = await db.get_chat_settings(chat_id)
        new_val = 0 if current.get(setting_key) else 1
        await db.update_chat_setting(chat_id, setting_key, new_val)
        updated = await db.get_chat_settings(chat_id)
        await query.edit_message_reply_markup(reply_markup=get_dashboard_keyboard(chat_id, updated))

    elif action == "refresh":
        chat_id = int(parts[1])
        settings = await db.get_chat_settings(chat_id)
        await query.edit_message_reply_markup(reply_markup=get_dashboard_keyboard(chat_id, settings))

    elif action == "back" and parts[1] == "home":
        chat_id = int(parts[2])
        settings = await db.get_chat_settings(chat_id)
        await query.edit_message_text(
            get_text("welcome_dashboard", settings.get("language", "bn"), chat_title=settings.get("title", "Community")),
            reply_markup=get_dashboard_keyboard(chat_id, settings),
            parse_mode="Markdown"
        )

    elif action == "menu" and parts[1] == "stats":
        chat_id = int(parts[2])
        data_stats = await analytics.get_stats(chat_id)
        text = (
            f"📊 *গ্রুপ অ্যাক্টিভিটি রিপোর্ট*\n\n"
            f"🗑️ মুছে ফেলা মেসেজ: *{data_stats['deleted']}*\n"
            f"⚠️ প্রদত্ত সতর্কবার্তা: *{data_stats['warns']}*\n"
            f"🔇 প্রয়োগকৃত মিউট: *{data_stats['mutes']}*\n"
            f"🚫 নিষিদ্ধ সদস্য (ব্যান): *{data_stats['bans']}*"
        )
        await query.edit_message_text(text, reply_markup=get_back_keyboard(chat_id), parse_mode="Markdown")

    elif action == "menu" and parts[1] == "punish":
        chat_id = int(parts[2])
        settings = await db.get_chat_settings(chat_id)
        await query.edit_message_text(
            "⚙️ *শাস্তি নির্ধারণ প্যানেল*\nসর্বোচ্চ ওয়ার্ন অতিক্রম করার পর সদস্যের বিরুদ্ধে কী ব্যবস্থা নেওয়া হবে?",
            reply_markup=get_punish_settings_keyboard(chat_id, settings.get("warn_action", "mute")),
            parse_mode="Markdown"
        )

    elif action == "setaction":
        new_action = parts[1]
        chat_id = int(parts[2])
        await db.update_chat_setting(chat_id, "warn_action", new_action)
        await query.edit_message_reply_markup(reply_markup=get_punish_settings_keyboard(chat_id, new_action))

    elif action == "menu" and parts[1] == "lang":
        chat_id = int(parts[2])
        settings = await db.get_chat_settings(chat_id)
        new_lang = "en" if settings.get("language") == "bn" else "bn"
        await db.update_chat_setting(chat_id, "language", new_lang)
        updated = await db.get_chat_settings(chat_id)
        await query.edit_message_reply_markup(reply_markup=get_dashboard_keyboard(chat_id, updated))

    elif action == "menu" and parts[1] == "words":
        chat_id = int(parts[2])
        words = await db.get_blacklisted_words(chat_id)
        list_txt = "\n".join([f"• `{w}`" for w in words]) if words else "কোনো শব্দ তালিকাভুক্ত নেই।"
        text = f"💬 *কাস্টম নিষিদ্ধ শব্দসমূহ:*\n\n{list_txt}\n\nশব্দ যোগ করতে কমান্ড দিন:\n`/addword <শব্দ>`"
        await query.edit_message_text(text, reply_markup=get_back_keyboard(chat_id), parse_mode="Markdown")

    elif action == "menu" and parts[1] == "links":
        chat_id = int(parts[2])
        domains = await db.get_allowed_domains(chat_id)
        list_txt = "\n".join([f"• `{d}`" for d in domains]) if domains else "কোনো অনুমোদিত ডোমেইন নেই।"
        text = f"🌐 *অনুমোদিত ডোমেইন তালিকা (Whitelist):*\n\n{list_txt}\n\nডোমেইন অনুমোদন দিতে কমান্ড দিন:\n`/allowlink <domain>`"
        await query.edit_message_text(text, reply_markup=get_back_keyboard(chat_id), parse_mode="Markdown")

    elif action == "menu" and parts[1] == "voices":
        chat_id = int(parts[2])
        await voice_settings_message(query, chat_id)

    elif action == "voice" and parts[1] == "delete":
        voice_id = int(parts[2])
        chat_id = int(parts[3])
        deleted = await db.delete_moderation_voice(voice_id)
        await voice_settings_message(query, chat_id)

    elif action == "menu" and parts[1] == "ai":
        chat_id = int(parts[2])
        context.user_data["current_chat_id"] = chat_id
        context.user_data["awaiting_ai"] = True
        await query.edit_message_text(
            "🤖 <b>NIRVOY AI CONTROL</b>\n\n"
            "এখন আমাকে বাংলায় বলুন—কী জানতে চান বা কোন নিরাপদ moderation setting পরিবর্তন করতে চান।\n\n"
            "উদাহরণ: <i>এই গ্রুপে anti-promo চালু রাখো</i>\n"
            "অথবা: <i>বর্তমান security settings দেখাও</i>\n\n"
            "⚠️ পরিবর্তনের আগে confirmation চাইবে।",
            reply_markup=ai_menu_keyboard(chat_id),
            parse_mode="HTML"
        )

    elif action == "ai":
        chat_id = int(parts[2])
        if parts[1] == "start":
            context.user_data["current_chat_id"] = chat_id
            context.user_data["awaiting_ai"] = True
            await query.edit_message_text(
                "🤖 AI chat চালু। বাংলায় আপনার নির্দেশ/প্রশ্ন লিখুন।\n\n"
                "উদাহরণ: <i>প্রমোশন detection কেন কাজ করছে?</i>",
                reply_markup=get_back_keyboard(chat_id),
                parse_mode="HTML"
            )
        elif parts[1] == "status":
            await send_ai_status(query.edit_message_text)

        elif parts[1] == "settings":
            settings = await db.get_chat_settings(chat_id)
            words = await db.get_blacklisted_words(chat_id)
            domains = await db.get_allowed_domains(chat_id)
            await query.edit_message_text(
                format_settings(settings, words, domains),
                reply_markup=ai_menu_keyboard(chat_id),
                parse_mode="HTML"
            )
        elif parts[1] == "confirm":
            pending = context.user_data.get("pending_ai_action")
            pending_chat = context.user_data.get("pending_ai_chat_id")
            if not pending or pending_chat != chat_id:
                await query.edit_message_text("⚠️ কোনো pending AI change পাওয়া যায়নি।")
                return
            ok, msg = await execute_ai_action(chat_id, pending)
            context.user_data.pop("pending_ai_action", None)
            context.user_data.pop("pending_ai_chat_id", None)
            await query.edit_message_text(
                ("✅ " if ok else "❌ ") + msg,
                reply_markup=ai_menu_keyboard(chat_id),
                parse_mode="HTML"
            )
        elif parts[1] == "cancel":
            context.user_data.pop("pending_ai_action", None)
            context.user_data.pop("pending_ai_chat_id", None)
            await query.edit_message_text(
                "❌ AI পরিবর্তন বাতিল করা হয়েছে।",
                reply_markup=ai_menu_keyboard(chat_id)
            )

    elif action == "auth" and parts[1] == "logout":
        terminate_session(user.id)
        await query.edit_message_text("🚪 আপনি অ্যাডমিন সেশন থেকে নিরাপদে প্রস্থান করেছেন।")