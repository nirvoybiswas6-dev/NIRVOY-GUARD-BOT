import asyncio
import html
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, filters
from database.db import db
from utils.security import is_session_valid
from config import OWNER_ID
from utils.logger import log

DELETE_AFTER_SECONDS = 300

async def upload_voice_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    message = update.effective_message
    user = update.effective_user
    chat = update.effective_chat
    if not message or not user or not chat or chat.type != "private":
        return
    if user.id != OWNER_ID and not is_session_valid(user.id):
        return

    file_id = None
    kind = "voice"
    name = "ভয়েস মেসেজ"
    if message.voice:
        file_id = message.voice.file_id
        kind = "voice"
        name = "ভয়েস মেসেজ"
    elif message.audio:
        file_id = message.audio.file_id
        kind = "audio"
        name = message.audio.file_name or message.audio.title or "অডিও ফাইল"
    elif message.document:
        doc = message.document
        filename = (doc.file_name or "").lower()
        mime = (doc.mime_type or "").lower()
        if not (mime.startswith("audio/") or filename.endswith((".ogg", ".opus", ".mp3", ".m4a", ".wav", ".aac", ".flac"))):
            return
        file_id = doc.file_id
        kind = "audio"
        name = doc.file_name or "অডিও ফাইল"
    else:
        return

    caption = (message.caption or "").strip()
    ok = await db.add_moderation_voice(file_id, kind, name, user.id, caption)
    if ok:
        voices = await db.get_moderation_voices()
        await message.reply_text(
            f"✅ ভয়েস/অডিও সংরক্ষণ হয়েছে।\nমোট সংরক্ষিত ভয়েস: {len(voices)}\n\n"
            "লিংক/প্রমোশন ধরা পড়লে বট শুধু ভয়েস/অডিও পাঠাবে; কোনো সতর্কবার্তার টেক্সট পাঠাবে না।"
        )
    else:
        await message.reply_text("⚠️ এই ভয়েসটি আগে থেকেই সংরক্ষিত, অথবা সংরক্ষণ করা যায়নি।")

async def voice_settings_message(query, chat_id: int):
    voices = await db.get_moderation_voices()
    lines = ["🔊 <b>লিংক/প্রমোশন সতর্কবার্তা ভয়েস</b>", "", "ভয়েস যোগ করতে এই বটের ইনবক্সে voice message বা audio file পাঠান।"]
    keyboard = []
    if voices:
        lines += ["", f"✅ সংরক্ষিত ভয়েস: {len(voices)}", "প্রয়োজন হলে নিচের বাটন দিয়ে যেকোনো ভয়েস মুছুন:"]
        for v in voices:
            label = html.escape((v.get("file_name") or "ভয়েস").strip())
            if len(label) > 28:
                label = label[:25] + "..."
            keyboard.append([InlineKeyboardButton(f"🗑️ মুছুন: {label}", callback_data=f"voice:delete:{v['id']}:{chat_id}")])
    else:
        lines += ["", "⚠️ এখনো কোনো ভয়েস সংরক্ষিত নেই।"]
    keyboard.append([InlineKeyboardButton("🔄 তালিকা রিফ্রেশ", callback_data=f"menu:voices:{chat_id}")])
    keyboard.append([InlineKeyboardButton("🔙 প্রধান মেনু", callback_data=f"back:home:{chat_id}")])
    await query.edit_message_text("\n".join(lines), reply_markup=InlineKeyboardMarkup(keyboard), parse_mode="HTML")

async def send_moderation_voice(chat, user, context, source_message=None):
    """Reply with a voice directly in the same group; never DM the member."""
    voice = await db.get_next_moderation_voice()
    if not voice:
        log.warning("মডারেশন ভয়েস পাঠানো হয়নি: কোনো ভয়েস সংরক্ষিত নেই")
        return

    kwargs = {"chat_id": chat.id}
    if source_message is not None:
        kwargs["reply_to_message_id"] = source_message.message_id
        # Keep the reply even if Telegram clients hide the deleted source message.
        kwargs["allow_sending_without_reply"] = True
    try:
        if voice["file_kind"] == "audio":
            sent = await context.bot.send_audio(audio=voice["file_id"], caption=(voice.get("caption") or None), **kwargs)
        else:
            sent = await context.bot.send_voice(voice=voice["file_id"], caption=(voice.get("caption") or None), **kwargs)
    except Exception as e:
        log.warning(f"গ্রুপে রিপ্লাই ভয়েস পাঠানো ব্যর্থ: {e}")
        return

    async def delete_later(msg):
        await asyncio.sleep(DELETE_AFTER_SECONDS)
        try:
            await msg.delete()
        except Exception as e:
            log.warning(f"৫ মিনিট পর ভয়েস ডিলিট ব্যর্থ: {e}")

    asyncio.create_task(delete_later(sent))
