from datetime import datetime, timedelta
from telegram import Update, ChatPermissions
from telegram.ext import ContextTypes
from database.db import db
from services.warning_service import warn_engine
from utils.validators import get_text
from utils.logger import log

async def is_user_admin(chat, user_id: int) -> bool:
    try:
        member = await chat.get_member(user_id)
        return member.status in ["administrator", "creator"]
    except Exception:
        return False

async def warn_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat = update.effective_chat
    user = update.effective_user
    if not chat or not update.message or not update.message.reply_to_message:
        return
    if not await is_user_admin(chat, user.id):
        await update.message.reply_text("❌ আপনার এই কমান্ড ব্যবহারের অনুমতি নেই!")
        return

    target = update.message.reply_to_message.from_user
    if target.is_bot or await is_user_admin(chat, target.id):
        await update.message.reply_text("⚠️ অ্যাডমিন বা বটকে সতর্কবার্তা দেওয়া সম্ভব নয়!")
        return

    reason = " ".join(context.args) if context.args else "গ্রুপ নিয়ম লঙ্ঘন"
    count, max_warns = await warn_engine.add_warn(chat.id, target.id, reason)
    settings = await db.get_chat_settings(chat.id)
    lang = settings.get("language", "bn")

    await update.message.reply_text(
        get_text("user_warned", lang, user_mention=target.mention_html(), reason=reason, current=count, max=max_warns),
        parse_mode="HTML"
    )
    await db.log_action(chat.id, target.id, "WARN", f"Reason: {reason}, Count: {count}")

    if count >= max_warns:
        action = settings.get("warn_action", "mute")
        if action == "ban":
            await chat.ban_member(target.id)
            await update.message.reply_text(get_text("user_banned", lang, user_mention=target.mention_html()), parse_mode="HTML")
            await warn_engine.reset_warns(chat.id, target.id)
        elif action == "mute":
            duration = settings.get("mute_duration_mins", 60)
            until_date = datetime.utcnow() + timedelta(minutes=duration)
            await chat.restrict_member(target.id, ChatPermissions(can_send_messages=False), until_date=until_date)
            await update.message.reply_text(get_text("user_muted", lang, user_mention=target.mention_html(), duration=duration), parse_mode="HTML")
            await warn_engine.reset_warns(chat.id, target.id)

async def mute_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat = update.effective_chat
    user = update.effective_user
    if not chat or not update.message or not update.message.reply_to_message:
        return
    if not await is_user_admin(chat, user.id):
        return
    target = update.message.reply_to_message.from_user
    if await is_user_admin(chat, target.id):
        return

    mins = int(context.args[0]) if context.args and context.args[0].isdigit() else 30
    until = datetime.utcnow() + timedelta(minutes=mins)
    await chat.restrict_member(target.id, ChatPermissions(can_send_messages=False), until_date=until)
    settings = await db.get_chat_settings(chat.id)
    await update.message.reply_text(get_text("user_muted", settings.get("language", "bn"), user_mention=target.mention_html(), duration=mins), parse_mode="HTML")

async def unmute_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat = update.effective_chat
    user = update.effective_user
    if not chat or not update.message or not update.message.reply_to_message:
        return
    if not await is_user_admin(chat, user.id):
        return
    target = update.message.reply_to_message.from_user
    await chat.restrict_member(target.id, ChatPermissions(can_send_messages=True, can_send_media_messages=True, can_send_other_messages=True, can_add_web_page_previews=True))
    settings = await db.get_chat_settings(chat.id)
    await update.message.reply_text(get_text("user_unmuted", settings.get("language", "bn"), user_mention=target.mention_html()), parse_mode="HTML")

async def ban_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat = update.effective_chat
    user = update.effective_user
    if not chat or not update.message or not update.message.reply_to_message:
        return
    if not await is_user_admin(chat, user.id):
        return
    target = update.message.reply_to_message.from_user
    if await is_user_admin(chat, target.id):
        return
    await chat.ban_member(target.id)
    settings = await db.get_chat_settings(chat.id)
    await update.message.reply_text(get_text("user_banned", settings.get("language", "bn"), user_mention=target.mention_html()), parse_mode="HTML")

async def unban_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat = update.effective_chat
    user = update.effective_user
    if not chat or not context.args:
        return
    if not await is_user_admin(chat, user.id):
        return
    if context.args[0].isdigit():
        target_id = int(context.args[0])
        await chat.unban_member(target_id)
        settings = await db.get_chat_settings(chat.id)
        await update.message.reply_text(get_text("user_unbanned", settings.get("language", "bn"), user_mention=f"ID: {target_id}"), parse_mode="HTML")