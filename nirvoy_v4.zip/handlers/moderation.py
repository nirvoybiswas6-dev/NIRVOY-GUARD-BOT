import html
from telegram import Update
from telegram.ext import ContextTypes
from database.db import db
from services.spam_detector import spam_engine
from services.promotion_detector import promo_engine
from services.link_filter import link_engine
from services.raid_protection import raid_engine
from services.ai_detector import ai_engine
from handlers.commands import is_user_admin
from utils.logger import log
from handlers.voices import send_moderation_voice


async def _delete_with_log(message, chat, user, reason: str, action: str = "DELETE"):
    """Delete first so moderation is visible immediately; logging is best-effort."""
    try:
        await message.delete()
    except Exception as e:
        log.warning(f"মেসেজ ডিলিট ব্যর্থ: {e}")
        return False

    try:
        await db.log_action(chat.id, user.id, action, reason)
    except Exception as e:
        log.warning(f"অ্যাকশন লগ ব্যর্থ: {e}")
    return True


async def _notify(chat, user, header: str, reason: str):
    try:
        await chat.send_message(
            f"{header}\n\n"
            f"⚠️ {user.mention_html()}, গ্রুপে অননুমোদিত বিজ্ঞাপন, প্রমোশন বা লিংক নিষিদ্ধ হওয়ায় আপনার মেসেজটি মুছে ফেলা হয়েছে!\n"
            f"📌 <b>কারণ:</b> <i>{html.escape(reason)}</i>",
            parse_mode="HTML",
        )
    except Exception as e:
        log.warning(f"মডারেশন নোটিফিকেশন পাঠানো ব্যর্থ: {e}")


async def group_moderation_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat = update.effective_chat
    user = update.effective_user
    message = update.effective_message

    if not chat or not user or not message:
        return
    if chat.type not in ["group", "supergroup"]:
        return

    text = (message.text or message.caption or "").strip()
    if not text:
        return

    # অ্যাডমিন/ওনারদের মেসেজ বাইপাস
    if await is_user_admin(chat, user.id):
        return

    settings = await db.get_chat_settings(chat.id)

    # ১. স্প্যাম: সম্পূর্ণ local check — কোনো network/AI call নয়।
    if settings.get("anti_spam"):
        if (spam_engine.is_flooding(chat.id, user.id) or
            spam_engine.is_repeating(chat.id, user.id, text) or
            spam_engine.has_excessive_emojis(text) or
            spam_engine.has_char_repetition(text)):
            await send_moderation_voice(chat, user, context, message)
            await _delete_with_log(message, chat, user, "স্প্যামিং বা ফ্লাডিং শনাক্ত")
            return

    # ২. লিংক ফিল্টার FIRST. আগে AI চালানোর কারণে এতদিন link deletion slow হচ্ছিল।
    # URL থাকলে local regex/whitelist দিয়ে সরাসরি সিদ্ধান্ত নেওয়া হবে।
    if settings.get("anti_link"):
        whitelist = await db.get_allowed_domains(chat.id)
        allowed, reason = link_engine.validate_content_links(text, whitelist)
        if not allowed:
            await send_moderation_voice(chat, user, context, message)
            await _delete_with_log(
                message, chat, user, f"অননুমোদিত লিংক: {reason}"
            )
            return

    # ৩. Local promotion filter. এটি AI-এর চেয়ে অনেক দ্রুত।
    if settings.get("anti_promo"):
        blacklisted = await db.get_blacklisted_words(chat.id)
        is_promo, reason = promo_engine.is_promotional(text, blacklisted)

        if is_promo:
            await send_moderation_voice(chat, user, context, message)
            await _delete_with_log(
                message, chat, user, f"বিজ্ঞাপন (ফিল্টার): {reason}"
            )
            return

        # ৪. Local filter-এ ধরা না পড়লে শুধু তখন AI analysis।
        # Link already blocked হলে এখানে আসবে না, তাই সাধারণ link deletion দ্রুত থাকে।
        is_ai_promo, ai_reason = await ai_engine.analyze_promotion(text)
        if is_ai_promo:
            await send_moderation_voice(chat, user, context, message)
            await _delete_with_log(
                message, chat, user, f"বিজ্ঞাপন (AI অ্যানালাইসিস): {ai_reason}"
            )
            return


async def member_join_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat = update.effective_chat
    if not chat or not update.message or not update.message.new_chat_members:
        return

    settings = await db.get_chat_settings(chat.id)
    if settings.get("anti_raid"):
        for member in update.message.new_chat_members:
            if member.is_bot:
                continue
            if raid_engine.record_join_and_check(chat.id):
                await update.message.reply_text(
                    "🚨 <b>অস্বাভাবিক রেইড (Raid) শনাক্ত হয়েছে!</b>\n"
                    "গ্রুপের সদস্যদের সুরক্ষায় তাৎক্ষণিক স্বয়ংক্রিয় লকডাউন চালু করা হলো।",
                    parse_mode="HTML",
                )
                await db.update_chat_setting(chat.id, "lockdown", 1)
                break
