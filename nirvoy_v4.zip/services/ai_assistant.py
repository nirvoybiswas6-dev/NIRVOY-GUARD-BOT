import json
import re
from typing import Any, Dict

from services.gemini_client import gemini_client


class AIAssistant:
    """বাংলা AI admin assistant.

    সাধারণ chat-এ Gemini-এর স্বাভাবিক text response ব্যবহার করে।
    Configuration change-এর ক্ষেত্রে কেবল allow-listed action proposal গ্রহণ করে।
    """

    ALLOWED_SETTINGS = {
        "anti_spam", "anti_promo", "anti_link", "anti_raid", "delete_punish", "lockdown"
    }
    ALLOWED_WARN_ACTIONS = {"mute", "ban", "kick"}

    async def chat_or_plan(
        self,
        user_text: str,
        settings: Dict[str, Any],
        blacklisted: list[str],
        allowed_domains: list[str],
    ) -> Dict[str, Any]:
        text = (user_text or "").strip()
        if not text:
            return {"type": "answer", "answer": "আপনার প্রশ্নটি লিখুন। 🙂"}

        # IMPORTANT: ordinary conversation must NOT be forced through a JSON parser.
        # This was the source of the previous "নিরাপদভাবে বুঝতে পারিনি" problem.
        if not self._looks_like_config_request(text):
            prompt = f"""
তুমি NIRVOY GUARD-এর friendly Bengali AI assistant।
ব্যবহারকারীর সাথে স্বাভাবিকভাবে বাংলা, English বা Banglish-এ কথা বলবে।
প্রশ্নের সরাসরি, পরিষ্কার ও সংক্ষিপ্ত উত্তর দাও।
তুমি Telegram bot-এর নিরাপত্তা/মডারেশন সম্পর্কিত প্রশ্নে সাহায্য করতে পারো।
কিন্তু Python, shell, SQL, arbitrary code বা নিরাপত্তা bypass-এর নির্দেশ দেবে না।
শুধু plain text উত্তর দেবে; JSON, markdown code fence বা বিশেষ wrapper ব্যবহার করবে না।

বর্তমান bot context:
{json.dumps({"settings": {k: settings.get(k) for k in self.ALLOWED_SETTINGS | {"max_warns", "warn_action", "language"}}, "blacklisted_words": blacklisted[:50], "allowed_domains": allowed_domains[:50]}, ensure_ascii=False)}

ব্যবহারকারীর প্রশ্ন:
{text[:3000]}
"""
            ok, raw, error = await gemini_client.generate(prompt, temperature=0.5, max_tokens=700)
            if not ok:
                return {"type": "answer", "answer": f"AI এখন উত্তর দিতে পারছে না।\n\n📌 {error}"}
            answer = self._extract_plain_text(raw)
            return {"type": "answer", "answer": answer[:4000] or "AI কোনো উত্তর ফেরত দেয়নি। আবার চেষ্টা করুন।"}

        # Configuration requests use a constrained JSON response.
        context = {
            "settings": {k: settings.get(k) for k in self.ALLOWED_SETTINGS | {"max_warns", "warn_action", "language"}},
            "blacklisted_words": blacklisted[:100],
            "allowed_domains": allowed_domains[:100],
        }
        prompt = f"""
তুমি NIRVOY GUARD-এর বাংলা AI admin assistant।
শুধু নিরাপদ moderation configuration proposal তৈরি করবে।

শুধু এই action অনুমোদিত:
- set_setting: key=anti_spam|anti_promo|anti_link|anti_raid|delete_punish|lockdown; value=true/false
- add_blacklist: word
- remove_blacklist: word
- add_domain: domain
- remove_domain: domain
- set_warn_action: mute|ban|kick
- set_max_warns: integer 1..10
- show_settings
- none

Configuration change হলে admin confirmation লাগবে।
Python/shell/SQL/file operation/arbitrary code কখনো প্রস্তাব করবে না।

IMPORTANT: নিচের object-টি অবশ্যই valid JSON হতে হবে এবং একটিই object দিতে হবে।
কোনো markdown/code fence বা অতিরিক্ত text দেবে না।

বর্তমান configuration:
{json.dumps(context, ensure_ascii=False)}

Admin message:
{text[:2000]}

Expected JSON shape:
{{
  "type": "answer" অথবা "action",
  "answer": "type=answer হলে বাংলা উত্তর",
  "action": {{
    "name": "set_setting|add_blacklist|remove_blacklist|add_domain|remove_domain|set_warn_action|set_max_warns|show_settings|none",
    "value": true/false/string/number/object/null,
    "reason": "বাংলায় সংক্ষিপ্ত কারণ"
  }}
}}
"""
        ok, raw, error = await gemini_client.generate_json(prompt, temperature=0.1, max_tokens=500)
        if not ok:
            # Fallback to normal text so a temporary JSON-format/model issue does not
            # break the AI chat completely.
            return {"type": "answer", "answer": f"AI এখন পরিবর্তনের অনুরোধটি প্রক্রিয়া করতে পারছে না।\n\n📌 {error}"}

        cleaned = clean_json(raw)
        try:
            result = json.loads(cleaned)
            if isinstance(result, dict):
                return self._validate_result(result)
        except Exception:
            pass

        embedded = extract_json_object(cleaned)
        if embedded:
            try:
                result = json.loads(embedded)
                if isinstance(result, dict):
                    return self._validate_result(result)
            except Exception:
                pass

        return {"type": "answer", "answer": "অনুরোধটির configuration action নিরাপদভাবে বোঝা যায়নি। একটু পরিষ্কার করে লিখুন—যেমন: ‘anti-promo চালু করো’।"}

    def _looks_like_config_request(self, text: str) -> bool:
        """Only route explicit configuration requests through JSON/action mode."""
        t = text.lower()
        phrases = [
            "setting", "settings", "config", "configuration", "security settings",
            "anti-spam", "anti spam", "anti-promo", "anti promo", "anti-link", "anti link",
            "anti-raid", "anti raid", "blacklist", "black list", "whitelist", "white list",
            "warn action", "max warns", "lockdown", "enable", "disable", "turn on", "turn off",
            "চালু কর", "চালু রাখ", "বন্ধ কর", "বন্ধ রাখ", "সেটিং", "কনফিগ", "কনফিগার",
            "ব্ল্যাকলিস্ট", "হোয়াইটলিস্ট", "হোয়াইটলিস্ট", "নিষিদ্ধ শব্দ", "যোগ কর", "যোগ করুন",
            "বাদ দাও", "বাদ দিন", "সেট কর", "পরিবর্তন কর", "পরিবর্তন করুন", "অন কর", "অফ কর",
            "লকডাউন", "সিকিউরিটি চালু", "security on", "security off",
        ]
        return any(p in t for p in phrases)

    def _extract_plain_text(self, raw: str) -> str:
        text = (raw or "").strip()
        # If a model still returns a simple JSON answer object in normal-chat mode,
        # gracefully extract its answer instead of displaying the wrapper.
        cleaned = clean_json(text)
        try:
            obj = json.loads(cleaned)
            if isinstance(obj, dict) and obj.get("answer"):
                return str(obj["answer"]).strip()
        except Exception:
            pass
        return text

    def _validate_result(self, result: Dict[str, Any]) -> Dict[str, Any]:
        if result.get("type") == "answer":
            return {"type": "answer", "answer": str(result.get("answer", "দুঃখিত, বুঝতে পারিনি।"))[:3000]}
        if result.get("type") != "action":
            return {"type": "answer", "answer": "আমি অনুরোধটি নিরাপদভাবে বুঝতে পারিনি।"}

        action = result.get("action") or {}
        name = action.get("name")
        value = action.get("value")
        reason = str(action.get("reason", ""))[:500]
        allowed = {
            "set_setting", "add_blacklist", "remove_blacklist", "add_domain",
            "remove_domain", "set_warn_action", "set_max_warns", "show_settings", "none"
        }
        if name not in allowed:
            return {"type": "answer", "answer": "এই ধরনের পরিবর্তন AI-এর অনুমোদিত তালিকায় নেই।"}
        if name == "set_setting":
            if not isinstance(value, dict) or value.get("key") not in self.ALLOWED_SETTINGS or not isinstance(value.get("value"), bool):
                return {"type": "answer", "answer": "সেটিং পরিবর্তনের অনুরোধটি বৈধ নয়।"}
        elif name in {"add_blacklist", "remove_blacklist", "add_domain", "remove_domain"}:
            if not isinstance(value, str) or not value.strip() or len(value.strip()) > 120:
                return {"type": "answer", "answer": "শব্দ/ডোমেইনটি বৈধ নয়।"}
            value = value.strip()
        elif name == "set_warn_action":
            if value not in self.ALLOWED_WARN_ACTIONS:
                return {"type": "answer", "answer": "শাস্তির action বৈধ নয়।"}
        elif name == "set_max_warns":
            try:
                value = int(value)
                if not 1 <= value <= 10:
                    raise ValueError
            except Exception:
                return {"type": "answer", "answer": "max warns 1 থেকে 10-এর মধ্যে হতে হবে।"}
        return {"type": "action", "action": {"name": name, "value": value, "reason": reason}}


def clean_json(raw: str) -> str:
    raw = (raw or "").strip()
    if raw.startswith("```"):
        lines = raw.splitlines()
        if lines and lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        raw = "\n".join(lines).strip()
    return raw


def extract_json_object(text: str) -> str:
    start = text.find("{")
    if start < 0:
        return ""
    depth = 0
    in_string = False
    escaped = False
    for i in range(start, len(text)):
        ch = text[i]
        if in_string:
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == '"':
                in_string = False
            continue
        if ch == '"':
            in_string = True
        elif ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                return text[start:i + 1]
    return ""


ai_assistant = AIAssistant()
