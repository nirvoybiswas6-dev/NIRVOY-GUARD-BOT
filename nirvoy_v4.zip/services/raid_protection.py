import time
from collections import defaultdict
from typing import Dict, List

class RaidProtection:
    def __init__(self, limit: int = 6, window_seconds: float = 8.0):
        self.limit = limit
        self.window = window_seconds
        self._join_events: Dict[int, List[float]] = defaultdict(list)
        self._lockdown_chats = set()

    def record_join_and_check(self, chat_id: int) -> bool:
        now = time.time()
        events = self._join_events[chat_id]
        events = [t for t in events if now - t <= self.window]
        events.append(now)
        self._join_events[chat_id] = events
        if len(events) >= self.limit:
            self._lockdown_chats.add(chat_id)
            return True
        return False

    def is_locked(self, chat_id: int) -> bool:
        return chat_id in self._lockdown_chats

    def unlock(self, chat_id: int):
        self._lockdown_chats.discard(chat_id)
        self._join_events[chat_id] = []

raid_engine = RaidProtection()