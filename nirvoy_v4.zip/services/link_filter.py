import re
from urllib.parse import urlparse
from typing import List, Tuple

class LinkFilter:
    URL_PATTERN = re.compile(r'(https?://[^\s]+|www\.[^\s]+|[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}(?:/[^\s]*)?)')
    SHORTENERS = {"bit.ly", "tinyurl.com", "cutt.ly", "t.co", "shorturl.at", "rb.gy"}

    def extract_urls(self, text: str) -> List[str]:
        return self.URL_PATTERN.findall(text)

    def is_allowed(self, url: str, whitelist: List[str]) -> bool:
        if not url.startswith("http://") and not url.startswith("https://"):
            url = "http://" + url
        try:
            parsed = urlparse(url)
            domain = parsed.netloc.lower()
            if domain.startswith("www."):
                domain = domain[4:]
            if domain in self.SHORTENERS:
                return False
            for allowed in whitelist:
                allowed = allowed.lower().strip()
                if domain == allowed or domain.endswith("." + allowed):
                    return True
            return False
        except Exception:
            return False

    def validate_content_links(self, text: str, whitelist: List[str]) -> Tuple[bool, str]:
        urls = self.extract_urls(text)
        if not urls:
            return True, ""
        if not whitelist:
            return False, "অননুমোদিত এক্সটার্নাল লিংক"
        for url in urls:
            if not self.is_allowed(url, whitelist):
                return False, f"অননুমোদিত লিংক/ডোমেইন: {url}"
        return True, ""

link_engine = LinkFilter()