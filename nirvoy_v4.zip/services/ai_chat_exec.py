from database.db import db
from services.ai_assistant import AIAssistant

_ALLOWED_SETTINGS = AIAssistant.ALLOWED_SETTINGS
_ALLOWED_ACTIONS = {"mute", "ban", "kick"}

async def execute_ai_action(chat_id: int, action: dict):
    name = action.get("name")
    value = action.get("value")

    if name == "set_setting":
        if not isinstance(value, dict):
            return False, "অবৈধ setting payload।"
        key = value.get("key")
        val = value.get("value")
        if key not in _ALLOWED_SETTINGS or not isinstance(val, bool):
            return False, "এই setting পরিবর্তন অনুমোদিত নয়।"
        await db.update_chat_setting(chat_id, key, 1 if val else 0)
        return True, f"<b>{key}</b> {'চালু' if val else 'বন্ধ'} করা হয়েছে।"

    if name == "add_blacklist":
        ok = await db.add_blacklisted_word(chat_id, str(value).strip())
        return ok, "নিষিদ্ধ শব্দটি যোগ করা হয়েছে।" if ok else "শব্দটি আগে থেকেই তালিকায় আছে।"

    if name == "remove_blacklist":
        ok = await db.remove_blacklisted_word(chat_id, str(value).strip())
        return ok, "নিষিদ্ধ শব্দটি বাদ দেওয়া হয়েছে।" if ok else "শব্দটি তালিকায় পাওয়া যায়নি।"

    if name == "add_domain":
        domain = str(value).lower().strip().replace("https://", "").replace("http://", "").split("/")[0]
        ok = await db.add_allowed_domain(chat_id, domain)
        return ok, f"<b>{domain}</b> whitelist-এ যোগ করা হয়েছে।" if ok else "ডোমেইনটি আগে থেকেই whitelist-এ আছে।"

    if name == "remove_domain":
        domain = str(value).lower().strip().replace("https://", "").replace("http://", "").split("/")[0]
        ok = await db.remove_allowed_domain(chat_id, domain)
        return ok, f"<b>{domain}</b> whitelist থেকে বাদ দেওয়া হয়েছে।" if ok else "ডোমেইনটি whitelist-এ পাওয়া যায়নি।"

    if name == "set_warn_action":
        if value not in _ALLOWED_ACTIONS:
            return False, "অবৈধ warn action।"
        await db.update_chat_setting(chat_id, "warn_action", value)
        return True, f"Warn action <b>{value}</b> করা হয়েছে।"

    if name == "set_max_warns":
        try:
            n = int(value)
        except Exception:
            return False, "max warns বৈধ নয়।"
        if not 1 <= n <= 10:
            return False, "max warns 1-10 হতে হবে।"
        await db.update_chat_setting(chat_id, "max_warns", n)
        return True, f"Max warns <b>{n}</b> করা হয়েছে।"

    return False, "এই AI action সমর্থিত নয়।"
