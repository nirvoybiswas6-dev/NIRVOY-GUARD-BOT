"""Defensive Gemini REST client with model/API-version fallback."""
import json
from typing import Any, Dict, Optional, Tuple

import httpx

from config import GEMINI_API_KEY, GEMINI_MODEL, GEMINI_AUTO_MODEL
from utils.logger import log

# v1 is the stable API; v1beta is retained as a fallback for compatibility.
BASE_URLS = [
    "https://generativelanguage.googleapis.com/v1",
    "https://generativelanguage.googleapis.com/v1beta",
]


class GeminiClient:
    def __init__(self):
        self.api_key = GEMINI_API_KEY.strip()
        self.configured_model = GEMINI_MODEL.strip() or "gemini-2.5-flash"
        self.auto_model = GEMINI_AUTO_MODEL
        self.active_model: Optional[str] = None
        self.active_base_url: Optional[str] = None
        self.last_error: str = ""

    @property
    def ready(self) -> bool:
        return bool(self.api_key)

    def _model_name(self, value: str) -> str:
        return value.split("/", 1)[1] if value.startswith("models/") else value

    async def list_models(self) -> Tuple[bool, list[str], str]:
        """List models, preferring stable v1 and falling back to v1beta."""
        if not self.ready:
            return False, [], "GEMINI_API_KEY সেট করা নেই।"

        last_error = ""
        try:
            async with httpx.AsyncClient(timeout=15) as client:
                for base_url in BASE_URLS:
                    try:
                        r = await client.get(
                            f"{base_url}/models",
                            headers={"x-goog-api-key": self.api_key},
                        )
                    except httpx.HTTPError as exc:
                        last_error = f"{base_url}: {type(exc).__name__}"
                        continue

                    if r.status_code != 200:
                        last_error = self._error_reason(r.status_code, r.text)
                        continue

                    data = r.json()
                    names = []
                    for item in data.get("models", []):
                        methods = item.get("supportedGenerationMethods", [])
                        if "generateContent" in methods:
                            name = self._model_name(item.get("name", ""))
                            if name and name not in names:
                                names.append(name)
                    self.active_base_url = base_url
                    return True, names, ""
        except Exception as exc:
            log.warning(f"Gemini model list failed: {type(exc).__name__}: {exc}")
            last_error = "Gemini server-এ পৌঁছানো যাচ্ছে না।"

        return False, [], last_error or "Gemini model list পাওয়া যায়নি।"

    async def resolve_model(self) -> Tuple[bool, str, str]:
        if not self.ready:
            self.last_error = "GEMINI_API_KEY সেট করা নেই।"
            return False, "", self.last_error
        if self.active_model and self.active_base_url:
            return True, self.active_model, ""

        preferred = self._model_name(self.configured_model)
        ok, models, error = await self.list_models()
        if not ok:
            # Listing can fail on some network/proxy setups. Try configured model
            # directly against both API versions in generate().
            self.active_model = preferred
            self.active_base_url = None
            return True, preferred, ""

        if preferred in models:
            self.active_model = preferred
            return True, preferred, ""

        # Prefer currently common text-generation models, but only select models
        # actually advertised by this API key.
        fallback_order = [
            "gemini-2.5-flash",
            "gemini-2.5-flash-lite",
            "gemini-2.5-pro",
            "gemini-2.0-flash",
            "gemini-2.0-flash-lite",
            "gemini-1.5-flash",
            "gemini-flash-latest",
            "gemini-flash-lite-latest",
        ]
        for candidate in fallback_order:
            if candidate in models:
                self.active_model = candidate
                return True, candidate, ""

        # Last resort: use the first advertised generateContent model.
        if models:
            self.active_model = models[0]
            return True, models[0], ""

        self.last_error = "এই API key-এর জন্য generateContent সমর্থনকারী কোনো Gemini model পাওয়া যায়নি।"
        return False, "", self.last_error

    async def _generate_once(self, base_url: str, model: str, payload: Dict[str, Any]) -> tuple[int, str]:
        async with httpx.AsyncClient(timeout=30) as client:
            r = await client.post(
                f"{base_url}/models/{model}:generateContent",
                headers={
                    "x-goog-api-key": self.api_key,
                    "Content-Type": "application/json",
                },
                json=payload,
            )
        return r.status_code, r.text

    async def generate_json(self, prompt: str, *, temperature: float = 0.1, max_tokens: int = 500) -> Tuple[bool, str, str]:
        """Generate JSON using Gemini structured-output mode when available."""
        return await self._generate_with_config(
            prompt,
            temperature=temperature,
            max_tokens=max_tokens,
            extra_generation_config={"responseMimeType": "application/json"},
        )

    async def _generate_with_config(
        self, prompt: str, *, temperature: float, max_tokens: int,
        extra_generation_config: Optional[Dict[str, Any]] = None,
    ) -> Tuple[bool, str, str]:
        if not self.ready:
            self.last_error = "GEMINI_API_KEY সেট করা নেই।"
            return False, "", self.last_error

        ok, model, error = await self.resolve_model()
        if not ok:
            return False, "", error

        generation_config = {
            "temperature": temperature,
            "maxOutputTokens": max_tokens,
        }
        if extra_generation_config:
            generation_config.update(extra_generation_config)

        payload: Dict[str, Any] = {
            "contents": [{"parts": [{"text": prompt}]}],
            "generationConfig": generation_config,
        }

        base_urls = [self.active_base_url] if self.active_base_url else []
        base_urls += [u for u in BASE_URLS if u not in base_urls]
        candidates = [model]
        if self.auto_model:
            ok_list, models, _ = await self.list_models()
            if ok_list:
                preferred_order = [
                    "gemini-2.5-flash", "gemini-2.5-flash-lite", "gemini-2.5-pro",
                    "gemini-2.0-flash", "gemini-2.0-flash-lite", "gemini-1.5-flash",
                    "gemini-flash-latest", "gemini-flash-lite-latest",
                ]
                for candidate in preferred_order + models:
                    if candidate in models and candidate not in candidates:
                        candidates.append(candidate)

        errors = []
        for base_url in base_urls:
            for candidate in candidates:
                try:
                    status, body = await self._generate_once(base_url, candidate, payload)
                except httpx.TimeoutException:
                    errors.append(f"{candidate}: timeout")
                    continue
                except httpx.HTTPError:
                    errors.append(f"{candidate}: network error")
                    continue
                if status == 200:
                    try:
                        data = json.loads(body)
                        candidates_data = data.get("candidates") or []
                        parts = candidates_data[0].get("content", {}).get("parts", []) if candidates_data else []
                        answer = "\n".join(p.get("text", "") for p in parts if p.get("text")).strip()
                    except Exception:
                        answer = ""
                    if answer:
                        self.active_model = candidate
                        self.active_base_url = base_url
                        self.last_error = ""
                        return True, answer, ""
                    errors.append(f"{candidate}: empty response")
                    continue
                reason = self._error_reason(status, body)
                errors.append(f"{candidate}: {reason}")
                if status in (401, 403, 429):
                    self.last_error = reason
                    return False, "", reason

        self.last_error = errors[0] if errors else "Gemini কোনো usable response দেয়নি।"
        return False, "", self.last_error

    async def generate(self, prompt: str, *, temperature: float = 0.2, max_tokens: int = 500) -> Tuple[bool, str, str]:
        if not self.ready:
            self.last_error = "GEMINI_API_KEY সেট করা নেই।"
            return False, "", self.last_error

        ok, model, error = await self.resolve_model()
        if not ok:
            return False, "", error

        payload: Dict[str, Any] = {
            "contents": [{"parts": [{"text": prompt}]}],
            "generationConfig": {
                "temperature": temperature,
                "maxOutputTokens": max_tokens,
            },
        }

        # If list_models selected an API version, try it first; otherwise try
        # stable v1 and beta. If a model returns 404, try the next advertised
        # candidate instead of stopping at the first failure.
        base_urls = [self.active_base_url] if self.active_base_url else []
        base_urls += [u for u in BASE_URLS if u not in base_urls]

        candidates = [model]
        if self.auto_model:
            ok_list, models, _ = await self.list_models()
            if ok_list:
                preferred_order = [
                    "gemini-2.5-flash", "gemini-2.5-flash-lite", "gemini-2.5-pro",
                    "gemini-2.0-flash", "gemini-2.0-flash-lite", "gemini-1.5-flash",
                    "gemini-flash-latest", "gemini-flash-lite-latest",
                ]
                for candidate in preferred_order + models:
                    if candidate in models and candidate not in candidates:
                        candidates.append(candidate)

        errors = []
        try:
            for base_url in base_urls:
                for candidate in candidates:
                    try:
                        status, body = await self._generate_once(base_url, candidate, payload)
                    except httpx.TimeoutException:
                        errors.append(f"{candidate}: timeout")
                        continue
                    except httpx.HTTPError as exc:
                        errors.append(f"{candidate}: network error")
                        continue

                    if status == 200:
                        data = json.loads(body)
                        candidates_data = data.get("candidates") or []
                        if not candidates_data:
                            continue
                        parts = candidates_data[0].get("content", {}).get("parts", [])
                        answer = "\n".join(p.get("text", "") for p in parts if p.get("text")).strip()
                        if answer:
                            self.active_model = candidate
                            self.active_base_url = base_url
                            self.last_error = ""
                            return True, answer, ""
                        continue

                    reason = self._error_reason(status, body)
                    errors.append(f"{candidate}: {reason}")
                    log.warning(f"Gemini generateContent error {status} on {base_url}/{candidate}: {body[:400]}")

                    # 401/403/429 are credential/quota issues; trying more models
                    # won't fix them, so stop early.
                    if status in (401, 403, 429):
                        self.last_error = reason
                        return False, "", reason

            # Give the user a useful error rather than hiding the actual cause.
            if errors:
                self.last_error = errors[0]
                return False, "", errors[0]
            self.last_error = "Gemini কোনো usable response দেয়নি।"
            return False, "", self.last_error
        except Exception as exc:
            log.warning(f"Gemini generation failed: {type(exc).__name__}: {exc}")
            self.last_error = f"Gemini API-তে অপ্রত্যাশিত সমস্যা: {type(exc).__name__}"
            return False, "", self.last_error

    @staticmethod
    def _error_reason(status: int, body: str) -> str:
        detail = ""
        try:
            data = json.loads(body)
            detail = data.get("error", {}).get("message", "")
        except Exception:
            pass
        if status in (401, 403):
            return "Gemini API key গ্রহণ করা হয়নি (401/403)। API key/Project permission পরীক্ষা করুন।"
        if status == 404:
            return "এই Gemini model/API version-এ generateContent পাওয়া যায়নি (404)। অন্য available model চেষ্টা করা হচ্ছে।"
        if status == 429:
            return "Gemini API quota/rate limit শেষ হয়েছে (429)। কিছুক্ষণ পরে আবার চেষ্টা করুন।"
        if status == 400:
            return f"Gemini request গ্রহণ করেনি (400)। {detail[:220]}".strip()
        return f"Gemini API error (HTTP {status}). {detail[:220]}".strip()


gemini_client = GeminiClient()
