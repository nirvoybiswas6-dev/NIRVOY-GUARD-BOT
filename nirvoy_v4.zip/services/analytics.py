import aiosqlite
from typing import Dict, Any
from config import DATABASE_PATH

class AnalyticsService:
    async def get_stats(self, chat_id: int) -> Dict[str, Any]:
        async with aiosqlite.connect(DATABASE_PATH) as conn:
            cursor = await conn.execute(
                "SELECT COUNT(*) FROM audit_logs WHERE chat_id = ? AND action = 'DELETE'",
                (chat_id,)
            )
            deleted = (await cursor.fetchone())[0]

            cursor = await conn.execute(
                "SELECT COUNT(*) FROM audit_logs WHERE chat_id = ? AND action = 'WARN'",
                (chat_id,)
            )
            warns = (await cursor.fetchone())[0]

            cursor = await conn.execute(
                "SELECT COUNT(*) FROM audit_logs WHERE chat_id = ? AND action = 'MUTE'",
                (chat_id,)
            )
            mutes = (await cursor.fetchone())[0]

            cursor = await conn.execute(
                "SELECT COUNT(*) FROM audit_logs WHERE chat_id = ? AND action = 'BAN'",
                (chat_id,)
            )
            bans = (await cursor.fetchone())[0]

            return {
                "deleted": deleted,
                "warns": warns,
                "mutes": mutes,
                "bans": bans
            }

analytics = AnalyticsService()