import re
import time
from collections import defaultdict
from typing import Dict, List, Tuple

class SpamDetector:
    def __init__(self):
        self._user_messages: Dict[Tuple[int, int], List[float]] = defaultdict(list)
        self._last_content: Dict[Tuple[int, int], str] = {}
        self._repeat_counts: Dict[Tuple[int, int], int] = defaultdict(int)

    def is_flooding(self, chat_id: int, user_id: int, limit: int = 5, window_seconds: float = 4.0) -> bool:
        now = time.time()
        timestamps = self._user_messages[(chat_id, user_id)]
        timestamps = [t for t in timestamps if now - t <= window_seconds]
        timestamps.append(now)
        self._user_messages[(chat_id, user_id)] = timestamps
        return len(timestamps) > limit

    def is_repeating(self, chat_id: int, user_id: int, text: str, threshold: int = 3) -> bool:
        clean_text = text.strip().lower()
        if not clean_text:
            return False
        last = self._last_content.get((chat_id, user_id), "")
        if clean_text == last:
            self._repeat_counts[(chat_id, user_id)] += 1
            if self._repeat_counts[(chat_id, user_id)] >= threshold:
                return True
        else:
            self._last_content[(chat_id, user_id)] = clean_text
            self._repeat_counts[(chat_id, user_id)] = 1
        return False

    def has_excessive_emojis(self, text: str, max_count: int = 10, ratio_threshold: float = 0.45) -> bool:
        emoji_pattern = re.compile(
            "[\U00010000-\U0010ffff\u2600-\u26ff\u2700-\u27bf]", flags=re.UNICODE
        )
        emojis = emoji_pattern.findall(text)
        total_len = len(text.strip())
        if not total_len:
            return False
        return len(emojis) > max_count or (total_len > 8 and (len(emojis) / total_len) > ratio_threshold)

    def has_char_repetition(self, text: str, limit: int = 7) -> bool:
        pattern = re.compile(r'(.)\1{' + str(limit) + r',}')
        return bool(pattern.search(text))

spam_engine = SpamDetector()