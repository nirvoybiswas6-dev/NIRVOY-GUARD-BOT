import json
import re
from typing import Tuple
from services.gemini_client import gemini_client
from utils.logger import log


class AIDetector:
    async def analyze_promotion(self, text: str) -> Tuple[bool, str]:
        clean_text = (text or "").strip()
        # অতি সংক্ষিপ্ত টেক্সট ফিল্টার
        if not clean_text or len(clean_text) < 4:
            return False, ""

        prompt = f"""
You are NIRVOY GUARD AI, an intelligent and strict Telegram group moderation system.
Analyze the following Bengali/Banglish/English message carefully. Determine if it is any form of unauthorized promotion, advertisement, selling, or commercial spam.

Message to analyze:
"{clean_text[:2000]}"

Criteria for promotion (is_promo = true):
1. Buying/selling offers: Panels (প্যানেল/পেনেল), game hacks/cheats, bots, scripts, diamonds, dollar buy/sell, accounts, subscriptions, etc.
2. Soliciting private messages or DMs: "আমাকে মেসেজ দেন", "ইনবক্সে আসুন", "নক দিন", "DM me", "PM me", "কিনতে চাইলে মেসেজ দিন", "ইনবক্সে নক করুন".
3. Deceptive or misspelled words to bypass filters: Using "পেনেল" instead of "প্যানেল", "সেল হবে", "নিতে নক দাও", etc.
4. Betting, gambling, referral links, invite links, online earning baits, or commercial broadcasts.

Criteria for normal chat (is_promo = false):
Normal conversations, general questions, greetings (কেমন আছেন, ভাইয়া এটা কি, help please, etc.).

You MUST respond strictly in valid JSON format:
{{
  "is_promo": true,
  "reason": "সংক্ষিপ্ত বাংলায় স্পষ্ট কারণ (যেমন: প্যানেল বিক্রির প্রমোশন ও ইনবক্সে মেসেজ চাওয়ার অনুরোধ)"
}}
"""
        # ১. প্রথমে structured JSON মোডে কল করা হবে
        ok, raw, error = await gemini_client.generate_json(prompt, temperature=0.1, max_tokens=400)
        
        # ২. fallback: যদি generate_json সাপোর্ট না করে তবে সাধারণ generate কল
        if not ok:
            ok, raw, error = await gemini_client.generate(prompt, temperature=0.1, max_tokens=400)

        if not ok:
            log.warning(f"AI promotion analysis unavailable: {error}")
            return False, ""

        data = self._parse_json(raw)
        if not data:
            log.warning(f"AI promotion JSON parse failed. Raw response: {raw[:200]}")
            return False, ""

        is_promo = bool(data.get("is_promo", False))
        reason = str(data.get("reason", "")).strip() or "অননুমোদিত বাণিজ্যিক বিজ্ঞাপন বা প্রমোশন শনাক্ত"
        return is_promo, reason

    def _parse_json(self, raw: str) -> dict:
        if not raw:
            return {}
        text = raw.strip()
        # ```json ... ``` কোড ব্লক রিমুভ করা
        if "```" in text:
            match = re.search(r"```(?:json)?\s*([\s\S]*?)\s*```", text, re.IGNORECASE)
            if match:
                text = match.group(1).strip()
        try:
            return json.loads(text)
        except Exception:
            pass
        # ভেতরের প্রথম { ... } অংশ এক্সট্র্যাক্ট করা
        match = re.search(r"(\{[\s\S]*\})", text)
        if match:
            try:
                return json.loads(match.group(1))
            except Exception:
                pass
        return {}


ai_engine = AIDetector()