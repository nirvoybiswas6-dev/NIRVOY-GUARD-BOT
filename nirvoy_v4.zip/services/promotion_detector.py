import re
from typing import List, Tuple

class PromotionDetector:
    DEFAULT_PATTERNS = [
        r"1xbet|melbet|linebet|betway|babu88|jeetbuzz|krikya|nagad\s*88",
        r"(ফ্রি|হ্যাক|পেইড)?\s*(প্যানেল|পেনেল|panel)\b",
        r"(প্যানেল|পেনেল|panel|হ্যাক|চিট|মোড|আইডি|ডলার|ডায়মন্ড|কয়েন|একাউন্ট)\s*(কিনতে|কিনুন|লাগলে|সেল|বিক্রি|আসে|আছে|নিবেন)",
        r"(কিনতে|নিতে|লাগলে)\s*(চাইলে\s*)?(আমাকে|আমারে|আমায়|ইনবক্সে|ইনবক্স|নক|মেসেজ|sms)",
        r"(আমাকে|আমারে|আমায়|ইনবক্সে|ইনবক্স|নক|মেসেজ|sms)\s*(দেন|দাও|দিন|করুন|করো|করেন|নক\s*দিন)",
        r"(সেল|বিক্রি)\s*(হবে|করব|করবো|করা\s*হবে)",
        r"ইনকাম\s*করুন|প্রতিদিন\s*\d+\s*টাকা|ঘরে\s*বসে\s*আয়|বিকাশ\s*পেমেন্ট",
        r"t\.me\/\+[a-zA-Z0-9_\-]+",
        r"t\.me\/joinchat\/[a-zA-Z0-9_\-]+",
        r"join\s*my\s*channel|subscribe\s*to\s*earn|free\s*crypto",
        r"referral\s*code|invite\s*code|use\s*my\s*code",
        r"wa\.me\/[0-9]+|chat\.whatsapp\.com\/[a-zA-Z0-9]+"
    ]

    def __init__(self):
        self._compiled_defaults = [re.compile(p, re.IGNORECASE) for p in self.DEFAULT_PATTERNS]

    def is_promotional(self, text: str, custom_words: List[str]) -> Tuple[bool, str]:
        if not text:
            return False, ""
        for pattern in self._compiled_defaults:
            if pattern.search(text):
                return True, "চিহ্নিত বাণিজ্যিক বা অননুমোদিত লিংক/প্রমোশন"
        lower_text = text.lower()
        for word in custom_words:
            if word and word.lower() in lower_text:
                return True, f"কাস্টম নিষিদ্ধ শব্দ: '{word}'"
        return False, ""

promo_engine = PromotionDetector()