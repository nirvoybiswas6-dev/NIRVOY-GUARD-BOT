import aiosqlite
from typing import Tuple
from config import DATABASE_PATH
from database.db import db
from utils.logger import log

class WarningService:
    async def add_warn(self, chat_id: int, user_id: int, reason: str) -> Tuple[int, int]:
        settings = await db.get_chat_settings(chat_id)
        max_warns = settings.get("max_warns", 3)
        async with aiosqlite.connect(DATABASE_PATH) as conn:
            cursor = await conn.execute(
                "SELECT warn_count FROM user_warnings WHERE chat_id = ? AND user_id = ?",
                (chat_id, user_id)
            )
            row = await cursor.fetchone()
            count = 1 if not row else row[0] + 1
            await conn.execute(
                """INSERT INTO user_warnings (chat_id, user_id, warn_count, last_reason, updated_at) 
                   VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
                   ON CONFLICT(chat_id, user_id) DO UPDATE SET 
                   warn_count = ?, last_reason = ?, updated_at = CURRENT_TIMESTAMP""",
                (chat_id, user_id, count, reason, count, reason)
            )
            await conn.commit()
            return count, max_warns

    async def reset_warns(self, chat_id: int, user_id: int):
        async with aiosqlite.connect(DATABASE_PATH) as conn:
            await conn.execute(
                "DELETE FROM user_warnings WHERE chat_id = ? AND user_id = ?",
                (chat_id, user_id)
            )
            await conn.commit()

    async def get_warn_count(self, chat_id: int, user_id: int) -> int:
        async with aiosqlite.connect(DATABASE_PATH) as conn:
            cursor = await conn.execute(
                "SELECT warn_count FROM user_warnings WHERE chat_id = ? AND user_id = ?",
                (chat_id, user_id)
            )
            row = await cursor.fetchone()
            return row[0] if row else 0

warn_engine = WarningService()